@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Once BASLAT.bat ile kurulumu tamamlayin.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m pip install pyinstaller
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name EforAjandam app.py
if errorlevel 1 goto fail
echo Hazir: dist\EforAjandam.exe
pause
exit /b 0
:fail
echo EXE olusturulamadi. Hata mesajini kontrol edin.
pause
exit /b 1
