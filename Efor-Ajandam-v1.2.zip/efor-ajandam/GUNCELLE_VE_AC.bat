@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Once calisan Efor Ajandam uygulamasindan E simgesi ile Cikis yapin.
echo Ardindan devam etmek icin bir tusa basin.
pause >nul
python -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name EforAjandam app.py
if errorlevel 1 goto fail
if not exist "%LOCALAPPDATA%\Programs\EforAjandam" mkdir "%LOCALAPPDATA%\Programs\EforAjandam"
copy /Y "dist\EforAjandam.exe" "%LOCALAPPDATA%\Programs\EforAjandam\EforAjandam.exe" >nul
if errorlevel 1 goto fail
start "" "%LOCALAPPDATA%\Programs\EforAjandam\EforAjandam.exe"
echo Guncellendi. Mevcut masaustu kisayolu yeni surumu acar.
pause
exit /b 0
:fail
echo Islem basarisiz. Yukaridaki hata mesajini paylasin.
pause
exit /b 1
