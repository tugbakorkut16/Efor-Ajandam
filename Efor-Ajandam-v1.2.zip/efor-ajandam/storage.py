import os
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta

PROJECTS = ['DenizBank', 'İş Bankası', 'Trusso', 'DT Cloud', 'Enerjisa', 'Gratis', 'Polsan', 'Experian', 'Aperture', 'İç Çalışma']
STATUSES = ['Yapılanlar', 'Beklenenler', 'Araştırılanlar', 'Tamamlandı']

class Store:
    def __init__(self, path=None):
        if path is None:
            root = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'EforAjandam'
            root.mkdir(parents=True, exist_ok=True)
            path = root / 'ajanda.db'
        self.path = str(path)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS entries (
          id INTEGER PRIMARY KEY, day TEXT NOT NULL, project TEXT NOT NULL,
          status TEXT NOT NULL, title TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '',
          minutes INTEGER NOT NULL DEFAULT 0 CHECK(minutes >= 0),
          waiting_for TEXT NOT NULL DEFAULT '', follow_up TEXT NOT NULL DEFAULT '',
          created TEXT NOT NULL, updated TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        ''')
        self.db.commit()

    def setting(self, key, default):
        row = self.db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return row[0] if row else default

    def set_setting(self, key, value):
        self.db.execute('INSERT OR REPLACE INTO settings VALUES (?,?)', (key, str(value)))
        self.db.commit()

    def save(self, data, entry_id=None):
        d = dict(data)
        datetime.strptime(d['day'], '%Y-%m-%d')
        if d['follow_up']:
            datetime.strptime(d['follow_up'], '%Y-%m-%d')
        d['project'] = d['project'].strip()
        d['title'] = d['title'].strip()
        if not d['title'] or not d['project']:
            raise ValueError('Müşteri ve iş açıklaması boş bırakılamaz.')
        if int(d['minutes']) < 0 or d['status'] not in STATUSES:
            raise ValueError('Geçersiz süre veya durum.')
        keys = ['day','project','status','title','notes','minutes','waiting_for','follow_up']
        now = datetime.now().isoformat(timespec='seconds')
        if entry_id:
            self.db.execute('UPDATE entries SET ' + ','.join(k+'=?' for k in keys) + ', updated=? WHERE id=?', [d[k] for k in keys]+[now,entry_id])
        else:
            cur = self.db.execute('INSERT INTO entries ('+','.join(keys)+',created,updated) VALUES ('+','.join('?' for _ in range(10))+')', [d[k] for k in keys]+[now,now])
            entry_id = cur.lastrowid
        self.db.commit()
        return entry_id

    def entries(self, start=None, end=None, status=None, project=None, query=''):
        parts, args = [], []
        for clause, value in [('day>=?',start),('day<=?',end),('status=?',status),('project=?',project)]:
            if value:
                parts.append(clause); args.append(value)
        if query:
            parts.append('(title LIKE ? OR notes LIKE ? OR waiting_for LIKE ?)')
            args.extend(['%'+query+'%']*3)
        sql = 'SELECT * FROM entries' + (' WHERE '+' AND '.join(parts) if parts else '')
        return [dict(r) for r in self.db.execute(sql+' ORDER BY day DESC, id DESC',args)]

    def get(self, entry_id):
        row = self.db.execute('SELECT * FROM entries WHERE id=?',(entry_id,)).fetchone()
        return dict(row) if row else None

    def delete(self, entry_id):
        self.db.execute('DELETE FROM entries WHERE id=?',(entry_id,)); self.db.commit()

    def backup(self, path):
        target = sqlite3.connect(str(path))
        with target:
            self.db.backup(target)
        target.close()

def elapsed_minutes(start, end):
    # Never silently count an overnight gap or a long unattended session.
    return max(1, min(120, int((end-start).total_seconds()/60)))

def in_work_hours(now, start, end, weekdays_only=True):
    if weekdays_only and now.weekday() >= 5:
        return False
    t = now.strftime('%H:%M')
    return start <= t < end

def export_xlsx(rows, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.worksheet.table import Table, TableStyleInfo
    wb = Workbook(); ws = wb.active; ws.title = 'Efor Kayıtları'
    headers = ['Tarih','Müşteri / Proje','Durum','İş Açıklaması','Notlar','Süre (dk)','Süre (saat)','Kimden Bekleniyor','Takip Tarihi']
    ws.append(headers)
    for r in rows:
        # Explicit string cells prevent formula execution from user notes.
        values = [r['day'],r['project'],r['status'],r['title'],r['notes'],r['minutes'],round(r['minutes']/60,2),r['waiting_for'],r['follow_up']]
        ws.append(values)
        for i, value in enumerate(values,1):
            if isinstance(value,str): ws.cell(ws.max_row,i).data_type = 's'
    ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions
    for c in ws[1]:
        c.font = Font(bold=True,color='FFFFFF'); c.fill = PatternFill('solid',fgColor='245B66')
    for col,width in zip('ABCDEFGHI',[14,24,20,60,65,14,16,26,16]): ws.column_dimensions[col].width=width
    for row in ws.iter_rows(min_row=2):
        for c in row: c.alignment=Alignment(vertical='top',wrap_text=True)
    summary=wb.create_sheet('Müşteri Özeti'); summary.append(['Müşteri / Proje','Toplam Dakika','Toplam Saat'])
    totals={}
    for r in rows: totals[r['project']]=totals.get(r['project'],0)+r['minutes']
    for name,minutes in sorted(totals.items()):
        summary.append([name,minutes,round(minutes/60,2)]); summary.cell(summary.max_row,1).data_type='s'
    for c in summary[1]: c.font=Font(bold=True)
    for col in 'ABC': summary.column_dimensions[col].width=26
    wb.save(path)
