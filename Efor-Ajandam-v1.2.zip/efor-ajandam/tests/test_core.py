import unittest
import tempfile
from pathlib import Path
from datetime import datetime
from storage import Store, elapsed_minutes, in_work_hours, export_xlsx
from openpyxl import load_workbook

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name); self.s=Store(self.root/'test.db')
        self.data=dict(day='2026-10-30',project='DenizBank',status='Araştırılanlar',title='Webswing inceleme',notes='Loglar kontrol edildi.',minutes=20,waiting_for='',follow_up='')
    def tearDown(self): self.s.db.close(); self.tmp.cleanup()
    def test_status_change_preserves_notes_and_time(self):
        eid=self.s.save(self.data); d=self.s.get(eid); d['status']='Beklenenler'; d['waiting_for']='Global'; self.s.save(d,eid)
        self.assertEqual(self.s.get(eid)['notes'],self.data['notes']); self.assertEqual(self.s.get(eid)['minutes'],20)
        self.assertEqual(len(self.s.entries(status='Beklenenler')),1); self.assertEqual(self.s.entries(start='2026-10-31'),[])
    def test_empty_input_rejected(self):
        d=dict(self.data,title=' ')
        with self.assertRaises(ValueError): self.s.save(d)
    def test_backup(self):
        self.s.save(self.data); self.s.backup(self.root/'backup.db'); other=Store(self.root/'backup.db')
        self.assertEqual(len(other.entries()),1); other.db.close()
    def test_schedule_and_elapsed(self):
        self.assertTrue(in_work_hours(datetime(2026,10,30,9), '09:00','18:00'))
        self.assertFalse(in_work_hours(datetime(2026,10,31,9), '09:00','18:00'))
        self.assertFalse(in_work_hours(datetime(2026,10,30,18), '09:00','18:00'))
        self.assertEqual(elapsed_minutes(datetime(2026,10,30,9),datetime(2026,10,30,9,25)),25)
        self.assertEqual(elapsed_minutes(datetime(2026,10,30,9),datetime(2026,10,31,9)),120)
    def test_excel(self):
        self.s.save(dict(self.data,title='=1+1')); path=self.root/'out.xlsx'; export_xlsx(self.s.entries(),path)
        wb=load_workbook(path); self.assertEqual(wb.active['D2'].data_type,'s'); self.assertEqual(wb['Müşteri Özeti']['B2'].value,20); wb.close()

if __name__=='__main__': unittest.main()
