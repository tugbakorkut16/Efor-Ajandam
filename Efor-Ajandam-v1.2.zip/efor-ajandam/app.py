import sys
from datetime import datetime, date, timedelta
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QDate, QTime, QLockFile, QStandardPaths
from PySide6.QtGui import QAction, QIcon, QPixmap, QPainter, QColor, QFont, QCursor
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QLineEdit, QComboBox, QDateEdit, QSpinBox, QTextEdit, QFormLayout, QDialog,
    QDialogButtonBox, QMessageBox, QFileDialog, QSystemTrayIcon, QMenu, QCheckBox, QTimeEdit)
from storage import Store, PROJECTS, STATUSES, elapsed_minutes, in_work_hours, export_xlsx

STYLE = '''
QWidget { font-family: 'Segoe UI'; font-size: 13px; color: #233640; }
QMainWindow, QDialog { background: #f3f6f8; }
QLabel#heading { font-size: 28px; font-weight: 700; color: #184f5b; }
QPushButton { background: #e2eaee; border: none; border-radius: 6px; padding: 9px 16px; }
QPushButton:hover { background: #cfdfe5; }
QPushButton#primary { background: #206875; color: white; font-weight: 600; }
QLineEdit, QComboBox, QSpinBox, QDateEdit, QTimeEdit, QTextEdit { background: white; border: 1px solid #ccd9df; border-radius: 4px; padding: 6px; }
QTableWidget { background: white; alternate-background-color: #f4f8fa; border: 1px solid #dce5e9; gridline-color: #e8eef1; }
QHeaderView::section { background: #e7eff2; padding: 8px; border: 0; font-weight: 600; }
QTabBar::tab { padding: 12px 22px; background: #e5edf1; }
QTabBar::tab:selected { background: #206875; color: white; }
'''

def date_edit(value=None):
    w=QDateEdit(QDate.fromString(value,'yyyy-MM-dd') if value else QDate.currentDate())
    w.setCalendarPopup(True); w.setDisplayFormat('dd.MM.yyyy'); return w

def button(label, callback, primary=False):
    b=QPushButton(label); b.clicked.connect(callback)
    if primary: b.setObjectName('primary')
    return b

class EntryDialog(QDialog):
    def __init__(self, parent, entry=None, minutes=0):
        super().__init__(parent); self.setWindowTitle('İş Kaydı'); self.resize(540,580)
        self.entry=entry; layout=QVBoxLayout(self); form=QFormLayout()
        self.day=date_edit(entry['day'] if entry else None)
        self.project=QComboBox(); self.project.setEditable(True)
        names=sorted(set(PROJECTS+[r['project'] for r in parent.store.entries()]))
        self.project.addItems(names)
        self.state=QComboBox(); self.state.addItems(STATUSES)
        self.title=QLineEdit(); self.title.setPlaceholderText('Örn. Webswing güncellemesi için globale yazıldı')
        self.notes=QTextEdit(); self.notes.setPlaceholderText('Teknik notlar, bağlantılar, gelen yanıtlar…')
        self.minutes=QSpinBox(); self.minutes.setRange(0,1440); self.minutes.setSuffix(' dakika'); self.minutes.setValue(minutes)
        self.who=QLineEdit(); self.follow=date_edit(); self.follow_enabled=QCheckBox('Takip tarihi belirle')
        self.follow.setEnabled(False); self.follow_enabled.toggled.connect(self.follow.setEnabled)
        for label,w in [('Tarih',self.day),('Müşteri / Proje',self.project),('Durum',self.state),('İş açıklaması',self.title),('Notlar',self.notes),('Harcanan süre',self.minutes),('Kimden bekleniyor?',self.who),('',self.follow_enabled),('Takip tarihi',self.follow)]: form.addRow(label,w)
        layout.addLayout(form)
        hint=QLabel('Beklenenler: yalnızca aktif çalıştığın süreyi gir. Bekleme süresi efor değildir.'); hint.setWordWrap(True); layout.addWidget(hint)
        if entry:
            self.project.setCurrentText(entry['project']); self.state.setCurrentText(entry['status'])
            self.title.setText(entry['title']); self.notes.setPlainText(entry['notes']); self.minutes.setValue(entry['minutes']); self.who.setText(entry['waiting_for'])
            if entry['follow_up']:
                self.follow_enabled.setChecked(True); self.follow.setDate(QDate.fromString(entry['follow_up'],'yyyy-MM-dd'))
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText('Kaydet'); buttons.button(QDialogButtonBox.Cancel).setText('Vazgeç')
        buttons.accepted.connect(self.save); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def save(self):
        data=dict(day=self.day.date().toString('yyyy-MM-dd'),project=self.project.currentText(),status=self.state.currentText(),title=self.title.text(),notes=self.notes.toPlainText(),minutes=self.minutes.value(),waiting_for=self.who.text(),follow_up=self.follow.date().toString('yyyy-MM-dd') if self.follow_enabled.isChecked() else '')
        try: self.parent().store.save(data,self.entry['id'] if self.entry else None)
        except Exception as e: QMessageBox.warning(self,'Kayıt yapılamadı',str(e)); return
        self.accept()

class Reminder(QDialog):
    def __init__(self,parent):
        super().__init__(parent); self.setWindowTitle('Kısa bir efor molası'); self.setWindowFlag(Qt.WindowStaysOnTopHint)
        self.setMinimumWidth(460); lay=QVBoxLayout(self)
        title=QLabel('Efor kaydı eklemek ister misin?'); title.setWordWrap(True); title.setObjectName('heading'); lay.addWidget(title)
        self.elapsed=elapsed_minutes(parent.anchor,datetime.now())
        lay.addWidget(QLabel(f'Tahmini süre: {self.elapsed} dakika · Kaydetmeden önce düzenleyebilirsin.'))
        lay.addWidget(button('Yeni iş kaydet',self.new,True))
        last=parent.last_work()
        if last:
            lab=QLabel('Önceki iş: '+last['project']+' — '+last['title']); lab.setWordWrap(True); lay.addWidget(lab)
            lay.addWidget(button('Önceki işe devam',self.continue_work))
        lay.addWidget(button('5 dakika ertele',self.reject))
        lay.addWidget(button('Mola / bu aralığı atla',self.skip))
        self.result_action='snooze'
    def showEvent(self, event):
        super().showEvent(event)
        screen=QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        if screen:
            area=screen.availableGeometry()
            self.move(max(area.left(),area.right()-self.width()-16), max(area.top(),area.bottom()-self.height()-16))
    def new(self):
        self.result_action='new'; self.accept()
    def continue_work(self):
        self.result_action='continue'; self.accept()
    def skip(self): self.result_action='skip'; self.accept()

class Settings(QDialog):
    def __init__(self,parent):
        super().__init__(parent); self.setWindowTitle('Hatırlatma Ayarları'); f=QFormLayout(self)
        self.interval=QSpinBox(); self.interval.setRange(1,180); self.interval.setValue(int(parent.store.setting('interval','20'))); self.interval.setSuffix(' dakika')
        self.start=QTimeEdit(QTime.fromString(parent.store.setting('start','09:00'),'HH:mm')); self.start.setDisplayFormat('HH:mm')
        self.end=QTimeEdit(QTime.fromString(parent.store.setting('end','18:00'),'HH:mm')); self.end.setDisplayFormat('HH:mm')
        self.weekdays=QCheckBox('Yalnızca hafta içi'); self.weekdays.setChecked(parent.store.setting('weekdays','1')=='1')
        self.enabled=QCheckBox('Hatırlatmalar açık'); self.enabled.setChecked(parent.store.setting('enabled','1')=='1')
        for label,w in [('Hatırlatma aralığı',self.interval),('Mesai başlangıcı',self.start),('Mesai bitişi',self.end),('',self.weekdays),('',self.enabled)]: f.addRow(label,w)
        b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); b.accepted.connect(self.save); b.rejected.connect(self.reject); f.addRow(b)
    def save(self):
        if self.start.time()>=self.end.time(): QMessageBox.warning(self,'Saat aralığı','Bitiş saati başlangıçtan sonra olmalı.'); return
        s=self.parent().store
        for k,v in [('interval',self.interval.value()),('start',self.start.time().toString('HH:mm')),('end',self.end.time().toString('HH:mm')),('weekdays',int(self.weekdays.isChecked())),('enabled',int(self.enabled.isChecked()))]: s.set_setting(k,v)
        self.accept()

class Window(QMainWindow):
    def __init__(self):
        super().__init__(); self.store=Store(); self.anchor=datetime.now(); self.next_due=self.anchor+timedelta(minutes=int(self.store.setting('interval','20'))); self.last_tick=self.anchor; self.busy=False; self.was_work=False
        self.setWindowTitle('Efor Ajandam'); self.resize(1200,740)
        root=QWidget(); self.setCentralWidget(root); layout=QVBoxLayout(root); layout.setContentsMargins(24,22,24,22); layout.setSpacing(16)
        top=QHBoxLayout(); title=QLabel('Efor Ajandam'); title.setObjectName('heading'); top.addWidget(title); top.addStretch()
        top.addWidget(button('+ İş kaydı',self.add,True)); top.addWidget(button('Hatırlatmayı dene',self.remind)); top.addWidget(button('Ayarlar',self.settings)); layout.addLayout(top)
        self.summary=QLabel(); layout.addWidget(self.summary)
        filters=QHBoxLayout(); self.start=date_edit(date.today().replace(day=1).isoformat()); self.end=date_edit()
        self.project=QComboBox(); self.query=QLineEdit(); self.query.setPlaceholderText('Açıklama, not veya kişi ara…')
        for text,w in [('Başlangıç',self.start),('Bitiş',self.end),('Müşteri',self.project)]: filters.addWidget(QLabel(text)); filters.addWidget(w)
        filters.addWidget(self.query,1); layout.addLayout(filters)
        self.tabs=QTabWidget(); self.tables=[]
        for name in ['Ajanda','Beklenenler','Araştırılanlar','Tamamlandı']:
            page=QWidget(); box=QVBoxLayout(page)
            if name in ['Beklenenler','Araştırılanlar']: box.addWidget(QLabel('Tüm tarihlerdeki açık işler gösterilir. Müşteri ve arama filtresi uygulanır.'))
            t=QTableWidget(0,7); t.setHorizontalHeaderLabels(['Tarih','Müşteri / Proje','İş Açıklaması','Süre','Kimden Bekleniyor','Takip','Durum']); t.setSelectionBehavior(QTableWidget.SelectRows); t.setSelectionMode(QTableWidget.SingleSelection); t.setEditTriggers(QTableWidget.NoEditTriggers); t.setAlternatingRowColors(True)
            t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); t.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch); t.doubleClicked.connect(self.edit)
            box.addWidget(t); self.tables.append(t); self.tabs.addTab(page,name)
        layout.addWidget(self.tabs,1)
        bottom=QHBoxLayout()
        for label,fn in [('Düzenle',self.edit),('Tamamlandı işaretle',self.complete),('Sil',self.delete),('Excel’e aktar',self.export),('Yedek al',self.backup)]: bottom.addWidget(button(label,fn))
        bottom.addStretch(); layout.addLayout(bottom)
        self.statusBar().showMessage('Kayıtlar bu bilgisayarda saklanır. Pencereyi kapattığında uygulama saat yanında çalışır.')
        for w in [self.start,self.end]: w.dateChanged.connect(self.refresh)
        self.project.currentTextChanged.connect(self.refresh); self.query.textChanged.connect(self.refresh)
        self.refresh_projects(); self.refresh(); self.setup_tray()
        self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(1000)
    def setup_tray(self):
        pix=QPixmap(64,64); pix.fill(QColor('#206875')); p=QPainter(pix); p.setPen(QColor('white')); p.setFont(QFont('Segoe UI',32,QFont.Bold)); p.drawText(pix.rect(),Qt.AlignCenter,'E'); p.end(); icon=QIcon(pix); self.setWindowIcon(icon)
        self.tray=QSystemTrayIcon(icon,self); self.tray.setToolTip('Efor Ajandam'); menu=QMenu()
        for label,fn in [('Ajandayı aç',self.open_window),('Şimdi kayıt ekle',self.add),('Çıkış',QApplication.instance().quit)]:
            a=QAction(label,self); a.triggered.connect(fn); menu.addAction(a)
        self.tray.setContextMenu(menu); self.tray.activated.connect(lambda reason:self.open_window() if reason==QSystemTrayIcon.Trigger else None); self.tray.show()
    def open_window(self): self.showNormal(); self.raise_(); self.activateWindow()
    def closeEvent(self,event):
        if QSystemTrayIcon.isSystemTrayAvailable():
            event.ignore(); self.hide(); self.tray.showMessage('Efor Ajandam','Hatırlatmalar mesai saatlerinde devam eder. Çıkış için saat yanındaki E simgesini kullan.')
        else: event.accept(); QApplication.instance().quit()
    def refresh_projects(self):
        current=self.project.currentText(); self.project.blockSignals(True); self.project.clear(); self.project.addItem('Tüm müşteriler'); self.project.addItems(sorted(set(PROJECTS+[r['project'] for r in self.store.entries()]))); self.project.setCurrentText(current or 'Tüm müşteriler'); self.project.blockSignals(False)
    def rows(self,index=None):
        i=self.tabs.currentIndex() if index is None else index
        return self.store.entries(start=self.start.date().toString('yyyy-MM-dd') if i not in [1,2] else None,end=self.end.date().toString('yyyy-MM-dd') if i not in [1,2] else None,status=[None,'Beklenenler','Araştırılanlar','Tamamlandı'][i],project=None if self.project.currentIndex()==0 else self.project.currentText(),query=self.query.text())
    def refresh(self):
        for i,t in enumerate(self.tables):
            rows=self.rows(i); t.setRowCount(len(rows))
            for n,r in enumerate(rows):
                vals=[r['day'],r['project'],r['title'],str(r['minutes'])+' dk',r['waiting_for'],r['follow_up'],r['status']]
                for col,val in enumerate(vals):
                    cell=QTableWidgetItem(val); cell.setData(Qt.UserRole,r['id']); cell.setToolTip(r['notes'])
                    if r['follow_up'] and r['follow_up']<=date.today().isoformat() and r['status'] in ['Beklenenler','Araştırılanlar']: cell.setBackground(QColor('#fff0ce'))
                    t.setItem(n,col,cell)
        today=self.store.entries(start=date.today().isoformat(),end=date.today().isoformat()); mins=sum(r['minutes'] for r in today)
        pending=self.store.entries(status='Beklenenler'); research=self.store.entries(status='Araştırılanlar')
        self.summary.setText(f'Bugün: {mins//60} saat {mins%60} dakika   •   Beklenen: {len(pending)}   •   Araştırılan: {len(research)}')
    def selected(self):
        t=self.tables[self.tabs.currentIndex()]; row=t.currentRow()
        return self.store.get(t.item(row,0).data(Qt.UserRole)) if row>=0 else None
    def reset_interval(self):
        self.anchor=datetime.now(); self.next_due=self.anchor+timedelta(minutes=int(self.store.setting('interval','20')))
    def add(self):
        self.busy=True
        try:
            if EntryDialog(self).exec()==QDialog.Accepted: self.reset_interval(); self.refresh_projects(); self.refresh()
        finally: self.busy=False
    def edit(self,*_):
        r=self.selected()
        if r:
            self.busy=True
            try:
                if EntryDialog(self,r).exec()==QDialog.Accepted: self.refresh_projects(); self.refresh()
            finally: self.busy=False
    def complete(self):
        r=self.selected()
        if r: r['status']='Tamamlandı'; self.store.save(r,r['id']); self.refresh()
    def delete(self):
        r=self.selected()
        if r and QMessageBox.question(self,'Kaydı sil','Bu kaydı silmek istiyor musun?')==QMessageBox.Yes: self.store.delete(r['id']); self.refresh()
    def last_work(self):
        return next((r for r in self.store.entries() if r['minutes']>0 and r['status']!='Beklenenler'),None)
    def remind(self):
        if self.busy: return
        self.busy=True
        try:
            while True:
                d=Reminder(self); d.exec()
                action=d.result_action
                if action not in ('new','continue'):
                    break
                # The reminder has finished its modal loop before opening the form.
                dialog=EntryDialog(self,minutes=d.elapsed)
                if action=='continue':
                    old=self.last_work()
                    if old:
                        dialog.project.setCurrentText(old['project'])
                        dialog.title.setText(old['title'])
                        dialog.notes.setPlainText('Önceki işe devam edildi.')
                if dialog.exec()==QDialog.Accepted:
                    action='saved'
                    break
            if action=='snooze': self.next_due=datetime.now()+timedelta(minutes=5)
            else: self.reset_interval()
            self.refresh_projects(); self.refresh()
        finally: self.busy=False
    def tick(self):
        now=datetime.now(); gap=(now-self.last_tick).total_seconds(); self.last_tick=now
        active=in_work_hours(now,self.store.setting('start','09:00'),self.store.setting('end','18:00'),self.store.setting('weekdays','1')=='1') and self.store.setting('enabled','1')=='1'
        if gap>90 or gap<0 or (active and not self.was_work): self.reset_interval()
        self.was_work=active
        if active and now>=self.next_due and not self.busy and QApplication.activeModalWidget() is None: self.remind()
    def settings(self):
        self.busy=True
        try:
            if Settings(self).exec()==QDialog.Accepted: self.reset_interval()
        finally: self.busy=False
    def export(self):
        path,_=QFileDialog.getSaveFileName(self,'Görünen kayıtları Excel’e aktar','efor-'+date.today().isoformat()+'.xlsx','Excel (*.xlsx)')
        if path:
            try: export_xlsx(self.rows(),path); QMessageBox.information(self,'Excel hazır','Seçili sekmedeki ve filtredeki kayıtlar aktarıldı.')
            except Exception as e: QMessageBox.warning(self,'Aktarılamadı',str(e))
    def backup(self):
        path,_=QFileDialog.getSaveFileName(self,'Veritabanını yedekle','ajanda-yedek-'+date.today().isoformat()+'.db','SQLite (*.db)')
        if path:
            try: self.store.backup(path); QMessageBox.information(self,'Yedek hazır','Tüm kayıtlar ve ayarlar yedeklendi.')
            except Exception as e: QMessageBox.warning(self,'Yedeklenemedi',str(e))

def main():
    app=QApplication(sys.argv); app.setApplicationName('EforAjandam'); app.setStyle('Fusion'); app.setStyleSheet(STYLE)
    lock=QLockFile(str(Path(Store().path).with_suffix('.lock'))); lock.setStaleLockTime(0)
    if not lock.tryLock(100): QMessageBox.information(None,'Efor Ajandam','Uygulama zaten açık. Saat yanındaki E simgesine tıkla.'); return
    app.setQuitOnLastWindowClosed(False)
    window=Window(); window.show(); sys.exit(app.exec())

if __name__=='__main__': main()
