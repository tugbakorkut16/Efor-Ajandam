# Efor Ajandam — ilk sürüm

Windows için kişisel efor ve iş takip uygulaması. Python + PySide6 + SQLite.

## İlk çalıştırma

1. ZIP dosyasını bir klasöre çıkar. ZIP içinden doğrudan çalıştırma.
2. Bilgisayarında Python 3.11 veya daha yeni bir Python 3 sürümü olmalı (Windows Python Launcher / `py` ile).
3. `BASLAT.bat` dosyasına çift tıkla. İlk çalıştırmada bağımlılıklar internetten yüklenir; sonraki kullanım çevrimdışıdır.
4. Uygulama açılınca **Ayarlar** bölümünden mesai saatlerini kontrol et. Varsayılan: hafta içi 09.00–18.00, her 20 dakikada bir.
5. **Hatırlatmayı dene** butonu ile pencereyi hemen açabilirsin; mesai dışında da deneme çalışır.

Bu paket kaynak kodudur, önceden derlenmiş EXE içermez. `EXE_OLUSTUR.bat` Windows bilgisayarında `dist\EforAjandam.exe` üretir. Derleme tamamlanınca bu EXE Python olmadan çalıştırılabilir. Windows üzerinde son kullanıcı testi henüz yapılmadı.

## İş akışı

- **İş kaydı**: tarih, müşteri, açıklama, notlar ve gerçekten çalışılan dakika.
- Müşteri listesine yeni bir adı doğrudan yazabilirsin. Kaydedilince listede kalır.
- **Ajanda**: seçilen tarih aralığındaki tüm kayıtlar.
- **Beklenenler**: kimden yanıt beklendiği ve isteğe bağlı takip tarihi. Tüm tarihlerdeki açık işleri gösterir.
- **Araştırılanlar**: teknik incelemeler ve notlar. Tüm tarihlerdeki açık işleri gösterir.
- Takip tarihi bugün veya geçmiş olan açık kayıtlar sarı renkle görünür.
- Bir kaydı çift tıklayarak düzenle. Durumunu değiştirerek beklenen/araştırılan/tamamlanan arasında taşı; notları korunur.
- **Tamamlandı işaretle**, seçilen kaydı tamamlar; eski notları ve süreyi silmez.
- Her kayıt tek güne ve tek süreye sahiptir. Başka bir gün aynı işe çalışırsan yeni kayıt aç.
- **Excel’e aktar**: o anda açık olan sekmenin filtrelenmiş kayıtlarını ve müşteri bazlı toplamını XLSX olarak kaydeder. Beklenenler/Araştırılanlar sekmelerinde tarih filtresi uygulanmaz.

## Hatırlatmalar

Uygulama çalışırken mesai saatlerinde 20 dakikada bir küçük pencere açar. Yeni kayıt, önceki işe devam, 5 dakika ertele veya mola seçenekleri vardır. Önceki işe devam seçeneği yeni bir kayıt formu açar; eklenen süreyi kontrol edip kaydet.

Süre son kayıt/atlama anından itibaren hesaplanır. Hatalı uzun süreleri önlemek için öneri 120 dakika ile sınırlıdır. Elle değiştirebilirsin. Mola seçeneği o aralığı kaydetmez ve sayacı yeniden başlatır. Erteleme, başlangıcı korur. Bilgisayar uykudan dönerse veya mesai yeni başladıysa sayaç yeniden başlar. Bilgisayar kilitliyken etkinlik ölçülmez; önerilen süreyi kontrol et.

X ile kapatınca saat yanında E simgesiyle çalışmaya devam eder. Tam kapatmak için simgeye sağ tıklayıp **Çıkış** seç. Bilgisayar kapalıyken veya uygulamadan çıkılmışken hatırlatma çalışmaz. Windows ile otomatik başlatma bu sürümde yoktur; istersen EXE kısayolunu `Win+R` → `shell:startup` klasörüne kendin ekleyebilirsin.

## Kayıtlar ve yedek

Kayıtlar `%LOCALAPPDATA%\EforAjandam\ajanda.db` dosyasında tutulur. Kaynak klasörünü başka yere taşımak kayıtları silmez. Veritabanı şifreli değildir; bilgisayar hesabının erişim izinleri geçerlidir. Uygulama notları herhangi bir sunucuya göndermez.

**Yedek al** ile tüm kayıtları ve ayarları bir `.db` dosyasına kaydet. Geri yükleme için uygulamadan tamamen çık, mevcut veritabanının kopyasını al, yedeği yukarıdaki konuma `ajanda.db` adıyla kopyala ve uygulamayı yeniden aç. Otomatik bulut eşitleme ve otomatik yedekleme yoktur.

## Geliştirici doğrulaması

`python -m unittest discover -s tests -v`

Doğrulama: SQLite kaydetme/güncelleme/filtreleme/yedekleme, mesai ve süre hesabı, Excel hücre güvenliği. Linux üzerinde Qt offscreen arayüz açılış testi uygulanmıştır; gerçek Windows bildirimleri ve sistem tepsisi davranışı Windows'ta kontrol edilmelidir.

## v1.1 güncellemesi

Hatırlatma sağ altta “Efor kaydı eklemek ister misin?” sorusuyla açılır. `GUNCELLE_VE_AC.bat` kaynak kodu derleyip kurulu EXE dosyasını günceller. Önce uygulamadan E simgesi → Çıkış yap. Kayıtlar korunur. Hızlı test için Ayarlar: aralık 1 dakika, Hatırlatmalar açık, Yalnızca hafta içi kapalı ve mevcut saat mesai aralığında olmalı. Ardından aralığı 20 dakikaya geri al.

## v1.2 düzeltmesi

Yeni iş kaydet ve Önceki işe devam seçilince hatırlatma kapanır, ardından kayıt formu açılır. Formdan vazgeçilirse hatırlatma yeniden gösterilir.
