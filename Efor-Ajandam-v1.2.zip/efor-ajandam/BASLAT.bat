@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto run
python --version >nul 2>&1
if errorlevel 1 (
 echo Python 3 bulunamadi. Python 3.11 veya daha yeni surumu kurup tekrar deneyin.
 pause
 exit /b 1
)
python -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
:run
.venv\Scripts\python.exe -c "import PySide6, openpyxl" >nul 2>&1
if errorlevel 1 (
 .venv\Scripts\python.exe -m pip install -r requirements.txt
 if errorlevel 1 goto fail
)
.venv\Scripts\python.exe app.py
if errorlevel 1 goto fail
exit /b 0
:fail
echo Islem tamamlanamadi. Yukaridaki hata mesajini paylasabilirsiniz.
pause
exit /b 1
